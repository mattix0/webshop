import { useLocation } from 'react-router'
import Navbar from '../../components/Navbar'
import Sidebar from '../../components/protected/Sidebar'

function Dashboard() {
  const location = useLocation()
  const username = location.state?.username

  return (
    <>
      <Navbar />

      <div className="flex min-h-[calc(100vh-64px)] items-start bg-gray-50">
        <Sidebar />

        <main className="flex-1 p-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <div className="bg-white rounded-2xl shadow border border-gray-200 p-5 text-center">
              <h4 className="text-sm text-gray-600">Pending</h4>
              <p className="mt-2 text-2xl font-medium text-gray-900">0</p>
            </div>

            <div className="bg-white rounded-2xl shadow border border-gray-200 p-5 text-center">
              <h4 className="text-sm text-gray-600">Shipping</h4>
              <p className="mt-2 text-2xl font-medium text-gray-900">0</p>
            </div>

            <div className="bg-white rounded-2xl shadow border border-gray-200 p-5 text-center">
              <h4 className="text-sm text-gray-600">Done</h4>
              <p className="mt-2 text-2xl font-medium text-gray-900">0</p>
            </div>

            <div className="bg-white rounded-2xl shadow border border-gray-200 p-5 text-center">
              <h4 className="text-sm text-gray-600">Costumers</h4>
              <p className="mt-2 text-2xl font-medium text-gray-900">0</p>
            </div>
          </div>

          <div className="bg-white rounded-2xl shadow border border-gray-200 p-6">
            {username && (
              <p className="mb-2">
                Welcome{' '}
                <span className="text-green-700 text-lg font-medium">{username}</span>
              </p>
            )}
            <p className="text-gray-600">This is the dashboard</p>
          </div>

          <div className="bg-white rounded-2xl shadow border border-gray-200 mt-5 overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200">
              <h3 className="text-base font-medium text-gray-900">Recent orders</h3>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="bg-gray-50 text-xs uppercase text-gray-600">
                  <tr>
                    <th scope="col" className="px-6 py-3 font-medium">Order</th>
                    <th scope="col" className="px-6 py-3 font-medium">Customer</th>
                    <th scope="col" className="px-6 py-3 font-medium">Date</th>
                    <th scope="col" className="px-6 py-3 font-medium">Status</th>
                    <th scope="col" className="px-6 py-3 font-medium text-right">Total</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200 text-gray-900">
                  <tr>
                    <td colSpan={5} className="px-6 py-12 text-center text-gray-500">
                      No orders yet
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

        </main>
      </div>
    </>
  )
}

export default Dashboard